# HesapKolay

Excel'e daha basit bir mobil alternatif olarak hazırlanan Flutter başlangıç projesi.

## İlk sürüm özellikleri
- Türkçe ana ekran ve alt menü
- Yerel SQLite veritabanında tablo saklama
- Yeni tablo oluşturma, açma ve silme
- Satır ve sütun ekleme
- Hücreleri düzenleme
- Basit hızlı hesap makinesi
- Gelir-gider ve stok şablonları için başlangıç yapısı
- GitHub Actions ile Android APK derleme

## APK oluşturma (GitHub Actions)
1. Bu dosyaları bir GitHub deposuna yükleyin.
2. **Actions** sekmesini açın.
3. **HesapKolay - Android APK** iş akışını seçin.
4. **Run workflow** düğmesine basın.
5. İşlem tamamlanınca **HesapKolay-APK** artifact'ini indirin.

## Önemli notlar
- Bu, ilk geliştirme başlangıcıdır; Google Play'e yüklemeden önce gerçek cihaz testleri yapılmalıdır.
- PDF/CSV dışa aktarma paketleri tanımlanmıştır ancak dışa aktarma arayüzü sonraki geliştirme adımında tamamlanacaktır.
- AdMob henüz eklenmemiştir. Önce temel uygulama ve kayıt davranışı test edilmelidir.
- Tablodaki toplam şu an ikinci sütundaki sayıları toplar; gelişmiş formül motoru sonraki sürümlerde eklenecektir.
