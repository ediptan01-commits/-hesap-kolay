import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await LocalStore.instance.init();
  runApp(const HesapKolayApp());
}

class LocalStore {
  LocalStore._();
  static final instance = LocalStore._();
  Database? _db;

  Future<void> init() async {
    final path = p.join(await getDatabasesPath(), 'hesap_kolay.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE sheets(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL,
          data TEXT NOT NULL,
          updated_at TEXT NOT NULL
        )
      ''');
    });
  }

  Future<List<Map<String, Object?>>> allSheets() async =>
      _db!.query('sheets', orderBy: 'id DESC');

  Future<int> createSheet(String title, String data) => _db!.insert('sheets', {
    'title': title,
    'data': data,
    'updated_at': DateTime.now().toIso8601String(),
  });

  Future<void> updateSheet(int id, String title, String data) async {
    await _db!.update('sheets', {
      'title': title,
      'data': data,
      'updated_at': DateTime.now().toIso8601String(),
    }, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteSheet(int id) async =>
      _db!.delete('sheets', where: 'id = ?', whereArgs: [id]);
}

class HesapKolayApp extends StatelessWidget {
  const HesapKolayApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'HesapKolay',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B52)),
      scaffoldBackgroundColor: const Color(0xFFF6F8F7),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFFF6F8F7),
        foregroundColor: Color(0xFF172B3A),
        elevation: 0,
      ),
    ),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _tab = 0;
  List<Map<String, Object?>> _sheets = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final rows = await LocalStore.instance.allSheets();
    if (!mounted) return;
    setState(() { _sheets = rows; _loading = false; });
  }

  Future<void> _newSheet([String? preset]) async {
    final title = TextEditingController(text: preset ?? '');
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Yeni tablo'),
        content: TextField(
          controller: title,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'Tablo adı',
            hintText: 'Örn. Aylık giderler',
            border: OutlineInputBorder(),
          ),
          onSubmitted: (_) => Navigator.pop(ctx, title.text.trim()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('İptal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, title.text.trim()), child: const Text('Oluştur')),
        ],
      ),
    );
    if (result == null || result.trim().isEmpty) return;
    final rows = preset == 'Gelir-Gider'
        ? [['Kalem', 'Tutar'], ['Maaş', '0'], ['Diğer gelir', '0'], ['Kira', '0'], ['Market', '0']]
        : preset == 'Stok Listesi'
          ? [['Ürün', 'Miktar', 'Birim fiyat'], ['Ürün 1', '0', '0']]
          : [['Açıklama', 'Miktar', 'Birim fiyat'], ['Kalem 1', '1', '0']];
    await LocalStore.instance.createSheet(result, _encode(rows));
    await _refresh();
    final sheet = _sheets.firstWhere((s) => s['title'] == result, orElse: () => {});
    if (sheet.isNotEmpty && mounted) await _openSheet(sheet);
  }

  String _encode(List<List<String>> rows) => rows.map((r) => r.map(_esc).join('\t')).join('\n');
  String _esc(String s) => s.replaceAll('%', '%25').replaceAll('\t', '%09').replaceAll('\n', '%0A');
  String _unesc(String s) => s.replaceAll('%0A', '\n').replaceAll('%09', '\t').replaceAll('%25', '%');

  List<List<String>> _decode(String data) => data.split('\n')
      .map((r) => r.split('\t').map(_unesc).toList()).toList();

  Future<void> _openSheet(Map<String, Object?> sheet) async {
    await Navigator.push(context, MaterialPageRoute(
      builder: (_) => SheetEditorPage(
        id: sheet['id'] as int,
        initialTitle: sheet['title'] as String,
        initialData: sheet['data'] as String,
        decode: _decode,
        encode: _encode,
        onDelete: () async {
          await LocalStore.instance.deleteSheet(sheet['id'] as int);
          await _refresh();
        },
      ),
    ));
    await _refresh();
  }

  @override
  Widget build(BuildContext context) {
    final titles = ['Ana Sayfa', 'Tablolarım', 'Şablonlar', 'Ayarlar'];
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(color: const Color(0xFF176B52), borderRadius: BorderRadius.circular(12)),
            child: const Icon(Icons.calculate_rounded, color: Colors.white),
          ),
          const SizedBox(width: 10),
          const Text('HesapKolay', style: TextStyle(fontWeight: FontWeight.w800)),
        ]),
        actions: [IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh_rounded), tooltip: 'Yenile')],
      ),
      body: _loading ? const Center(child: CircularProgressIndicator()) : IndexedStack(
        index: _tab,
        children: [
          _home(),
          _sheetList(),
          _templates(),
          _settings(),
        ],
      ),
      floatingActionButton: _tab < 2 ? FloatingActionButton.extended(
        onPressed: () => _newSheet(),
        icon: const Icon(Icons.add),
        label: const Text('Yeni tablo'),
      ) : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Ana Sayfa'),
          NavigationDestination(icon: Icon(Icons.table_chart_outlined), selectedIcon: Icon(Icons.table_chart), label: 'Tablolarım'),
          NavigationDestination(icon: Icon(Icons.dashboard_customize_outlined), selectedIcon: Icon(Icons.dashboard_customize), label: 'Şablonlar'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Ayarlar'),
        ],
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
    children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF176B52), Color(0xFF238568)]),
          borderRadius: BorderRadius.circular(24),
        ),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Hesaplarını kolaylaştır', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
          SizedBox(height: 8),
          Text('Tablolarını oluştur, hesapla ve telefonunda sakla.', style: TextStyle(color: Colors.white70)),
          SizedBox(height: 12),
          Row(children: [Icon(Icons.wifi_off, color: Colors.white, size: 18), SizedBox(width: 6), Text('İnternet olmadan da çalışır', style: TextStyle(color: Colors.white))]),
        ]),
      ),
      const SizedBox(height: 22),
      const Text('Hızlı işlemler', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      GridView.count(
        crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.55,
        children: [
          _quick('Yeni tablo', 'Kendi tablonu oluştur', Icons.add_box_outlined, () => _newSheet()),
          _quick('Gelir-Gider', 'Bütçeni takip et', Icons.account_balance_wallet_outlined, () => _newSheet('Gelir-Gider')),
          _quick('Stok listesi', 'Ürünlerini kaydet', Icons.inventory_2_outlined, () => _newSheet('Stok Listesi')),
          _quick('Hızlı hesap', 'Basit hesap makinesi', Icons.calculate_outlined, _calculator),
        ],
      ),
      const SizedBox(height: 22),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('Son tablolar', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        TextButton(onPressed: () => setState(() => _tab = 1), child: const Text('Tümünü gör')),
      ]),
      if (_sheets.isEmpty)
        const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('Henüz tablon yok. Başlamak için “Yeni tablo” düğmesine dokun.')))
      else
        ..._sheets.take(4).map(_sheetTile),
    ],
  );

  Widget _quick(String title, String subtitle, IconData icon, VoidCallback action) => Card(
    elevation: 0,
    color: Colors.white,
    child: InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: action,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: const Color(0xFF176B52), size: 25),
          const SizedBox(height: 8),
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          Text(subtitle, style: const TextStyle(fontSize: 11, color: Colors.black54), maxLines: 1, overflow: TextOverflow.ellipsis),
        ]),
      ),
    ),
  );

  Widget _sheetTile(Map<String, Object?> s) => Card(
    elevation: 0,
    child: ListTile(
      leading: const CircleAvatar(backgroundColor: Color(0xFFE5F5ED), child: Icon(Icons.table_chart, color: Color(0xFF176B52))),
      title: Text(s['title'] as String, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: const Text('Bu cihazda saklanıyor'),
      trailing: const Icon(Icons.chevron_right),
      onTap: () => _openSheet(s),
    ),
  );

  Widget _sheetList() => ListView(
    padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
    children: [
      const Text('Tablolarım', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Kayıtlı tabloların yalnızca bu telefonda saklanır.'),
      const SizedBox(height: 12),
      if (_sheets.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('Henüz kayıtlı tablo yok.')))
      else ..._sheets.map(_sheetTile),
    ],
  );

  Widget _templates() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('Hazır şablonlar', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Bir şablon seç, kendi bilgilerinle düzenle.'),
      const SizedBox(height: 12),
      _templateTile('Gelir-Gider', 'Gelir ve harcamalarını takip et', Icons.account_balance_wallet_outlined),
      _templateTile('Stok Listesi', 'Ürün ve miktarlarını kaydet', Icons.inventory_2_outlined),
      _templateTile('İnşaat Hesabı', 'Miktar ve birim fiyat hesapla', Icons.construction_outlined),
      _templateTile('Puantaj', 'Çalışma günlerini ve ücretleri takip et', Icons.calendar_month_outlined),
      _templateTile('Alışveriş Listesi', 'Ürün ve fiyatları düzenle', Icons.shopping_cart_outlined),
    ],
  );

  Widget _templateTile(String title, String desc, IconData icon) => Card(
    elevation: 0,
    child: ListTile(
      leading: Icon(icon, color: const Color(0xFF176B52)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text(desc),
      trailing: const Icon(Icons.add_circle_outline),
      onTap: () => _newSheet(title),
    ),
  );

  Widget _settings() => ListView(
    padding: const EdgeInsets.all(16),
    children: const [
      Text('Ayarlar', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      SizedBox(height: 12),
      Card(child: ListTile(leading: Icon(Icons.storage_outlined), title: Text('Veri saklama'), subtitle: Text('Veriler bu telefondaki yerel veritabanında tutulur.'))),
      Card(child: ListTile(leading: Icon(Icons.wifi_off), title: Text('Çevrimdışı kullanım'), subtitle: Text('Temel özellikler internet gerektirmez.'))),
      Card(child: ListTile(leading: Icon(Icons.info_outline), title: Text('HesapKolay'), subtitle: Text('İlk sürüm 1.0.0'))),
    ],
  );

  Future<void> _calculator() async {
    final a = TextEditingController();
    final b = TextEditingController();
    String op = '+';
    String result = '';
    await showDialog<void>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setDialog) => AlertDialog(
      title: const Text('Hızlı hesap'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: a, keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true), decoration: const InputDecoration(labelText: 'İlk sayı')),
        DropdownButton<String>(value: op, isExpanded: true, items: const [
          DropdownMenuItem(value: '+', child: Text('Toplama (+)')),
          DropdownMenuItem(value: '-', child: Text('Çıkarma (−)')),
          DropdownMenuItem(value: '*', child: Text('Çarpma (×)')),
          DropdownMenuItem(value: '/', child: Text('Bölme (÷)')),
        ], onChanged: (v) => setDialog(() => op = v!)),
        TextField(controller: b, keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true), decoration: const InputDecoration(labelText: 'İkinci sayı')),
        const SizedBox(height: 12),
        if (result.isNotEmpty) Text('Sonuç: $result', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Kapat')),
        FilledButton(onPressed: () {
          final x = double.tryParse(a.text.replaceAll(',', '.'));
          final y = double.tryParse(b.text.replaceAll(',', '.'));
          if (x == null || y == null || (op == '/' && y == 0)) {
            setDialog(() => result = 'Geçerli sayı girin');
            return;
          }
          final n = op == '+' ? x + y : op == '-' ? x - y : op == '*' ? x * y : x / y;
          setDialog(() => result = n.toStringAsFixed(4).replaceFirst(RegExp(r'\.?0+$'), ''));
        }, child: const Text('Hesapla')),
      ],
    )));
  }
}

class SheetEditorPage extends StatefulWidget {
  final int id;
  final String initialTitle;
  final String initialData;
  final List<List<String>> Function(String) decode;
  final String Function(List<List<String>>) encode;
  final Future<void> Function() onDelete;

  const SheetEditorPage({
    super.key, required this.id, required this.initialTitle, required this.initialData,
    required this.decode, required this.encode, required this.onDelete,
  });

  @override
  State<SheetEditorPage> createState() => _SheetEditorPageState();
}

class _SheetEditorPageState extends State<SheetEditorPage> {
  late TextEditingController _title;
  late List<List<String>> _rows;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _title = TextEditingController(text: widget.initialTitle);
    _rows = widget.decode(widget.initialData);
    if (_rows.isEmpty) _rows = [['Açıklama', 'Miktar', 'Birim fiyat']];
  }

  @override
  void dispose() { _title.dispose(); super.dispose(); }

  Future<void> _save() async {
    setState(() => _saving = true);
    await LocalStore.instance.updateSheet(widget.id, _title.text.trim().isEmpty ? 'Adsız tablo' : _title.text.trim(), widget.encode(_rows));
    if (mounted) setState(() => _saving = false);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tablo kaydedildi')));
  }

  void _addRow() => setState(() => _rows.add(List<String>.filled(_rows.isEmpty ? 2 : _rows.first.length, '')));
  void _addColumn() => setState(() { for (final row in _rows) { row.add(''); } });

  double _total() {
    if (_rows.length < 2) return 0;
    var sum = 0.0;
    for (final row in _rows.skip(1)) {
      if (row.length > 1) sum += double.tryParse(row[1].replaceAll(',', '.')) ?? 0;
    }
    return sum;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: TextField(controller: _title, decoration: const InputDecoration(border: InputBorder.none, hintText: 'Tablo adı'), style: const TextStyle(fontWeight: FontWeight.bold)),
      actions: [
        IconButton(onPressed: _save, icon: const Icon(Icons.save_outlined), tooltip: 'Kaydet'),
        PopupMenuButton<String>(
          onSelected: (v) async {
            if (v == 'row') _addRow();
            if (v == 'column') _addColumn();
            if (v == 'delete') {
              final yes = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
                title: const Text('Tablo silinsin mi?'),
                content: const Text('Bu işlem geri alınamaz.'),
                actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('İptal')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Sil'))],
              ));
              if (yes == true) { await widget.onDelete(); if (mounted) Navigator.pop(context); }
            }
          },
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'row', child: Text('Satır ekle')),
            PopupMenuItem(value: 'column', child: Text('Sütun ekle')),
            PopupMenuItem(value: 'delete', child: Text('Tabloyu sil')),
          ],
        ),
      ],
    ),
    body: Column(children: [
      Container(
        margin: const EdgeInsets.fromLTRB(12, 8, 12, 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: const Color(0xFFE5F5ED), borderRadius: BorderRadius.circular(14)),
        child: Row(children: [
          const Icon(Icons.functions, color: Color(0xFF176B52)),
          const SizedBox(width: 8),
          const Expanded(child: Text('İkinci sütundaki sayılar toplanır.', style: TextStyle(color: Color(0xFF176B52)))),
          Text(_total().toStringAsFixed(2), style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF176B52))),
        ]),
      ),
      Expanded(child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: SingleChildScrollView(
          child: DataTable(
            headingRowColor: WidgetStateProperty.all(const Color(0xFFEAF0ED)),
            columns: List.generate(_rows.first.length, (i) => DataColumn(
              label: SizedBox(width: 125, child: TextFormField(
                key: ValueKey('head-$i-${_rows.first[i]}'),
                initialValue: _rows.first[i],
                decoration: const InputDecoration(border: InputBorder.none, hintText: 'Sütun adı'),
                onChanged: (v) => _rows.first[i] = v,
              )),
            )),
            rows: List.generate(_rows.length - 1, (ri) {
              final rowIndex = ri + 1;
              while (_rows[rowIndex].length < _rows.first.length) { _rows[rowIndex].add(''); }
              return DataRow(cells: List.generate(_rows.first.length, (ci) => DataCell(
                SizedBox(width: 125, child: TextFormField(
                  key: ValueKey('cell-$rowIndex-$ci-${_rows[rowIndex][ci]}'),
                  initialValue: _rows[rowIndex][ci],
                  decoration: const InputDecoration(border: InputBorder.none, isDense: true),
                  keyboardType: ci == 0 ? TextInputType.text : const TextInputType.numberWithOptions(decimal: true, signed: true),
                  onChanged: (v) => _rows[rowIndex][ci] = v,
                )),
              )));
            }),
          ),
        ),
      )),
      SafeArea(top: false, child: Padding(
        padding: const EdgeInsets.all(12),
        child: SizedBox(width: double.infinity, child: FilledButton.icon(
          onPressed: _saving ? null : _save,
          icon: const Icon(Icons.save_outlined),
          label: Text(_saving ? 'Kaydediliyor…' : 'Tabloyu kaydet'),
        )),
      )),
    ]),
  );
}
